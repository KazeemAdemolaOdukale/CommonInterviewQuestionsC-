﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringReverseOrder
{
    /// <summary>
    /// write a function that returns a string in reverse order.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(StringReverse("Computers are fun"));
            Console.ReadLine();
        }

        private static string StringReverse(string stringToReverse)
        {
            char[] stringChar = stringToReverse.ToCharArray();
            Array.Reverse(stringChar);
            string stringReverse = new string(stringChar);
            return stringReverse;            
        }
    }
}
