﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighestOccurence
{
    class Program
    {
        static void Main(string[] args)
        {
            //test values.
            int[] array1 = { 1, 2, 2, 2, 2, 3, 1, 4 };
            int[] array2 = { 3, 3, 0, 10, 2, 3, 1 };
            int[] array3 = { 2, 1, 4, 4, 4, 1 };
            Console.WriteLine(NumWithHighestOccurence(array1));
            Console.WriteLine(NumWithHighestOccurence(array2));
            Console.WriteLine(NumWithHighestOccurence(array3));
            Console.ReadLine();
        }

        public static int NumWithHighestOccurence(int[] num)
        {
            // the strategy is to store the numbers and their number of occurence in a dictionary structure
            // the numbers will be Key of the dictionary while their number of occurence will be
            // corresponding values. Dictionary<TKey,TValue)
            // then write out from the dictionary Key of the maximum Value.

            Dictionary<int, int> dic = new Dictionary<int, int>();  // the dictionary
            int[] tem = new int[num.Length]; 
            num.CopyTo(tem, 0); // duplicate the array
            // take each element in the array and count it's occurency in the duplicated array.
            foreach (int number in num)  
            {
                int count = 0;
                // if we have already find occurency of a number and store in the
                // dictionary, we don't want to do it again, we want to go to the next number.
                if (dic.ContainsKey(number))
                {
                    continue;
                }
                else
                for (int i = 0; i < tem.Length; i++)  // counting done here.
                {                    
                        if (number == tem[i])
                        {
                            count++;                                           
                        }
                }
                dic.Add(number, count);
            }
            int max = dic.Values.Max(); // the highest occurency (highest value)
            // corresponding key of the highest occurency.
            return dic.Where(x => x.Value == max).Select(x => x.Key).FirstOrDefault();
        }
    }
}
