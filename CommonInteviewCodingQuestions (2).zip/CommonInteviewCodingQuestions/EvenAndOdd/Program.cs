﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvenAndOdd
{
    /// <summary>
    /// Write two functions that returns a boolean if an int is Even or Odd.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Even (4) {Even(4)}");
            Console.WriteLine($"Even (3) {Even(3)}");
            Console.WriteLine($"Odd (4) {Odd(4)}");
            Console.WriteLine($"Odd (3) {Odd(3)}");
            Console.ReadLine();
        }

        private static bool Even(int num)
        {
            int remainder = num % 2;
            if (remainder == 0)
                return true;
            return false;
        }

        private static bool Odd(int num)
        {
            return((num % 2) == 1 ? true : false);
        }
    }
}
